"""
Iris Flower Classification - Streamlit Web App
Author: Aparna Bitla

HOW TO RUN:
1. Make sure you have run notebooks/1_eda_hypothesis_testing and /2_model_building_evaluation.py first,
   so that models/best_model.pkl and models/scaler.pkl exist.
2. Install requirements:  pip install streamlit scikit-learn pandas numpy
3. From the project root, run:  streamlit run app/streamlit_app.py
4. It will open automatically in your browser at http://localhost:8501

"""
import pickle
import numpy as np
import streamlit as st

# ---------------------------------------------------------------------
# Load the trained model, scaler, and info about whether scaling is needed
# ---------------------------------------------------------------------
@st.cache_resource
def load_artifacts():
    with open("models/best_model.pkl", "rb") as f:
        model = pickle.load(f)
    with open("models/scaler.pkl", "rb") as f:
        scaler = pickle.load(f)
    with open("models/model_info.txt", "r") as f:
        info_lines = f.readlines()
    model_name = info_lines[0].split(":")[1].strip()
    needs_scaling = info_lines[1].split(":")[1].strip() == "True"
    accuracy = float(info_lines[2].split(":")[1].strip())
    return model, scaler, model_name, needs_scaling, accuracy


model, scaler, model_name, needs_scaling, accuracy = load_artifacts()

# ---------------------------------------------------------------------
# Page setup
# ---------------------------------------------------------------------
st.set_page_config(page_title="Iris Flower Classifier", page_icon="🌸", layout="centered")

st.title("🌸 Iris Flower Species Classifier")
st.write(
    f"This app predicts the species of an Iris flower "
    f"(Setosa, Versicolor, or Virginica) from its measurements, "
    f"using a **{model_name}** model (test accuracy: **{accuracy*100:.2f}%**)."
)

st.divider()

# ---------------------------------------------------------------------
# Input fields
# ---------------------------------------------------------------------
st.subheader("Enter Flower Measurements (cm)")

col1, col2 = st.columns(2)
with col1:
    sepal_length = st.slider("Sepal Length", 4.0, 8.0, 5.8, 0.1)
    petal_length = st.slider("Petal Length", 1.0, 7.0, 3.8, 0.1)
with col2:
    sepal_width = st.slider("Sepal Width", 2.0, 4.5, 3.0, 0.1)
    petal_width = st.slider("Petal Width", 0.1, 2.5, 1.2, 0.1)

# ---------------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------------
if st.button("Predict Species", type="primary"):
    features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])

    if needs_scaling:
        features = scaler.transform(features)

    prediction = model.predict(features)[0]

    st.success(f"### Predicted Species: **{prediction.capitalize()}**")

    species_info = {
        "setosa": "Setosa has the smallest petals and is easily distinguished from the other two species.",
        "versicolor": "Versicolor has medium-sized petals, overlapping somewhat with Virginica.",
        "virginica": "Virginica typically has the largest petals of the three species.",
    }
    st.info(species_info.get(prediction, ""))

st.divider()
st.caption("Iris Flower Classification | Data Science Internship Project | Naviotech Solutions")
