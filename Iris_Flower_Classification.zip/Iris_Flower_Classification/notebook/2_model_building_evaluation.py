# =====================================================================
# Iris Flower Classification - Model Building, Prediction & Evaluation
# Author: Aparna
# =====================================================================

# %% [1] Imports
import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# %% [2] Load cleaned data (produced by the EDA script)
df = pd.read_csv("../data/iris_cleaned.csv")

X = df[["sepal_length", "sepal_width", "petal_length", "petal_width"]]
y = df["species"]

# %% [3] Train/test split (70/30, stratified so each species is proportional)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y
)
print(f"Training samples: {len(X_train)}, Testing samples: {len(X_test)}")

# %% [4] Feature scaling (helps Logistic Regression & KNN converge/behave well)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# %% [5] Train the three required models
models = {
    "Logistic Regression": LogisticRegression(max_iter=200),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=5),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
}

results = {}

for name, model in models.items():
    # Logistic Regression & KNN benefit from scaled features; Decision Tree does not need it
    if name == "Decision Tree":
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
    else:
        model.fit(X_train_scaled, y_train)
        preds = model.predict(X_test_scaled)

    acc = accuracy_score(y_test, preds)
    cm = confusion_matrix(y_test, preds, labels=y.unique())
    report = classification_report(y_test, preds)

    results[name] = {
        "model": model,
        "accuracy": acc,
        "confusion_matrix": cm,
        "predictions": preds,
    }

    print(f"\n=== {name} ===")
    print(f"Accuracy: {acc:.4f} ({acc*100:.2f}%)")
    print("Confusion Matrix:")
    print(cm)
    print("Classification Report:")
    print(report)

# %% [6] Plot confusion matrices side by side
fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
labels_sorted = sorted(y.unique())
for ax, (name, res) in zip(axes, results.items()):
    sns.heatmap(res["confusion_matrix"], annot=True, fmt="d", cmap="Blues",
                xticklabels=labels_sorted, yticklabels=labels_sorted, ax=ax)
    ax.set_title(f"{name}\nAccuracy: {res['accuracy']*100:.2f}%")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
plt.tight_layout()
#plt.savefig("../plots/confusion_matrices.png", dpi=150)
plt.show()
plt.close()
print("\nSaved: confusion_matrices.png")

# %% [7] Model comparison summary
comparison = pd.DataFrame({
    "Model": list(results.keys()),
    "Accuracy": [results[m]["accuracy"] for m in results],
}).sort_values("Accuracy", ascending=False).reset_index(drop=True)

print("\n=== Model Comparison ===")
print(comparison)
comparison.to_csv("../data/model_comparison.csv", index=False)

# %% [8] Save the best-performing model for the Streamlit app
best_model_name = comparison.iloc[0]["Model"]
best_model = results[best_model_name]["model"]
print(f"\nBest performing model: {best_model_name}")

with open("../models/best_model.pkl", "wb") as f:
    pickle.dump(best_model, f)

with open("../models/scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

with open("../models/model_info.txt", "w") as f:
    f.write(f"Best model: {best_model_name}\n")
    f.write(f"Needs scaling: {best_model_name != 'Decision Tree'}\n")
    f.write(f"Accuracy: {results[best_model_name]['accuracy']:.4f}\n")

print("Saved best_model.pkl and scaler.pkl to ../models/")

# =====================================================================
# SUMMARY (copy into your report)
# =====================================================================
print(f"""
--- MODEL COMPARISON SUMMARY ---
All three models were trained on a 70/30 stratified train-test split.
{comparison.to_string(index=False)}

Because the Iris dataset has well-separated classes (especially thanks to
petal length/width), all three models perform very well. The best model
({best_model_name}) was saved for use in the Streamlit web app.
""")
