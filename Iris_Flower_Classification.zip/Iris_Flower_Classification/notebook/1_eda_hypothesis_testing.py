# =====================================================================
# Iris Flower Classification - Exploratory Data Analysis & Hypothesis Testing
# Author: Aparna Bitla
# =====================================================================
# This script can also be pasted cell-by-cell into a Jupyter Notebook.
# Each "# %%" marks a new cell if you open this file in Jupyter/VSCode.

# %% [1] Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.datasets import load_iris

sns.set_style("whitegrid")
plt.rcParams["figure.figsize"] = (8, 5)

# %% [2] Load the dataset
df = pd.read_csv("../data/iris.csv")

print("Shape of dataset:", df.shape)
print("\nFirst 5 rows:")
print(df.head())

print("\nData types:")
print(df.dtypes)

print("\nMissing values per column:")
print(df.isnull().sum())

# %% [3] Descriptive statistics grouped by species
desc_stats = df.groupby("species").agg(["mean", "median", "std"])
print("\nDescriptive statistics grouped by species:")
print(desc_stats)
desc_stats.to_csv("iris.csv")

# %% [4] Histograms for each feature
features = ["sepal_length", "sepal_width", "petal_length", "petal_width"]

fig, axes = plt.subplots(2, 2, figsize=(12, 8))
for ax, feature in zip(axes.flatten(), features):
    for species in df["species"].unique():
        sns.histplot(df[df["species"] == species][feature], ax=ax,
                     label=species, kde=True, alpha=0.5)
    ax.set_title(f"Distribution of {feature.replace('_',' ').title()}")
    ax.legend()
plt.tight_layout()
#plt.savefig("../plots", dpi=150)
plt.show()
plt.close()
print("histograms.png")

# %% [5] Scatter plots (feature relationships)
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
sns.scatterplot(data=df, x="petal_length", y="petal_width", hue="species", ax=axes[0])
axes[0].set_title("Petal Length vs Petal Width")
sns.scatterplot(data=df, x="sepal_length", y="sepal_width", hue="species", ax=axes[1])
axes[1].set_title("Sepal Length vs Sepal Width")
plt.tight_layout()
#plt.savefig("../plots/", dpi=150)
plt.show()
plt.close()
print("scatterplots.png")

# %% [6] Box plots for each feature by species
fig, axes = plt.subplots(2, 2, figsize=(12, 8))
for ax, feature in zip(axes.flatten(), features):
    sns.boxplot(data=df, x="species", y=feature, ax=ax)
    ax.set_title(f"{feature.replace('_',' ').title()} by Species")
plt.tight_layout()
#plt.savefig("../plots", dpi=150)
plt.show()
plt.close()
print("boxplots.png")

# %% [7] Correlation heatmap (bonus insight)
plt.figure(figsize=(6, 5))
sns.heatmap(df[features].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Feature Correlation Heatmap")
plt.tight_layout()
#plt.savefig("../plots", dpi=150)
plt.show()
plt.close()
print("correlation_heatmap.png")

# =====================================================================
# HYPOTHESIS TESTING
# =====================================================================

# %% [8] Hypothesis 1: Independent-samples t-test
# H0: There is no significant difference in mean sepal length between
#     Setosa and Versicolor.
# H1: There IS a significant difference in mean sepal length between
#     Setosa and Versicolor.

setosa_sepal_length = df[df["species"] == "setosa"]["sepal_length"]
versicolor_sepal_length = df[df["species"] == "versicolor"]["sepal_length"]

t_stat, p_value_t = stats.ttest_ind(setosa_sepal_length, versicolor_sepal_length)

print("\n--- Hypothesis 1: t-test on Sepal Length (Setosa vs Versicolor) ---")
print(f"Setosa mean sepal length:     {setosa_sepal_length.mean():.3f}")
print(f"Versicolor mean sepal length: {versicolor_sepal_length.mean():.3f}")
print(f"t-statistic = {t_stat:.4f}, p-value = {p_value_t:.6e}")
if p_value_t < 0.05:
    print("Result: Reject H0 -> The difference in mean sepal length IS statistically significant.")
else:
    print("Result: Fail to reject H0 -> No statistically significant difference found.")

# %% [9] Hypothesis 2: One-way ANOVA
# H0: The mean petal width is equal across all three species.
# H1: At least one species has a different mean petal width.

setosa_pw = df[df["species"] == "setosa"]["petal_width"]
versicolor_pw = df[df["species"] == "versicolor"]["petal_width"]
virginica_pw = df[df["species"] == "virginica"]["petal_width"]

f_stat, p_value_f = stats.f_oneway(setosa_pw, versicolor_pw, virginica_pw)

print("\n--- Hypothesis 2: One-way ANOVA on Petal Width (all 3 species) ---")
print(f"Setosa mean petal width:     {setosa_pw.mean():.3f}")
print(f"Versicolor mean petal width: {versicolor_pw.mean():.3f}")
print(f"Virginica mean petal width:  {virginica_pw.mean():.3f}")
print(f"F-statistic = {f_stat:.4f}, p-value = {p_value_f:.6e}")
if p_value_f < 0.05:
    print("Result: Reject H0 -> At least one species mean petal width differs significantly.")
else:
    print("Result: Fail to reject H0 -> No statistically significant difference found.")

# %% [10] Save cleaned dataset for the modelling stage
df.to_csv("../data/iris_cleaned.csv", index=False)
print("\nSaved cleaned dataset to data/iris_cleaned.csv")

# =====================================================================
# KEY INSIGHTS SUMMARY (also copy this into your report)
# =====================================================================
print("""
--- KEY INSIGHTS ---
1. Setosa is clearly separable from the other two species on petal length
   and petal width alone (near-zero overlap) - it is the "easy" class.
2. Versicolor and Virginica overlap more, especially on sepal width and
   sepal length, but separate reasonably well on petal measurements.
3. Petal length and petal width are the two most discriminative features
   for species classification (visible in scatter plots + high correlation
   with species separation).
4. Sepal width has the weakest separation power between species.
5. Hypothesis testing confirms these visual patterns are statistically
   significant, not due to random chance.
""")
